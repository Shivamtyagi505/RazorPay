import 'package:flutter/material.dart';

Widget brandName() {
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: <Widget>[
      Text(
        "Razor",
        style: TextStyle(
          color: Colors.black87,
          fontFamily: 'Overpass',
        ),
      ),
      Text(
        "Pay",
        style: TextStyle(color: Colors.blue, fontFamily: 'Overpass'),
      )
    ],
  );
}
